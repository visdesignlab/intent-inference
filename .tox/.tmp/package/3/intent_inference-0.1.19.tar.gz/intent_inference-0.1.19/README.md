# Intent Inference

Infer the intent of a selection for a given database.

Run `poetry version <bump-rule>` to increase the version before publishing. bump-rule has to be one of patch, minor, major, prepatch, preminor, premajor, prerelease
